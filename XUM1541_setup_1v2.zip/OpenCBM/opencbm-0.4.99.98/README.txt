ZoomFloppy file info
===
ZoomFloppy-Manual.pdf -- please read this before installing
install.bat -- installs OpenCBM binaries
firmware-update.bat -- update your ZoomFloppy's firmware
runtest.bat -- test if we can detect a drive after installation
windrv/ -- Windows USB device driver installer


Changes
===
Here are the changes in the versions, in reverse date order.

v2.0 (2011/9/24) -- Many improvements and bugfixes.
  * Add support for IEEE-488 drives.
    Implemented by Thomas Winkler.
  * Add experimental support for 1571 serial nibbling via the SRQ protocol.
    Now you don't need a parallel cable with a 1571. Implemented by Arnd Menge.
  * Add support for low-level drive analysis with a 1541 index-hole sensor.
    This works only on drives with a parallel port and nibtools.
  * Bugfix: cbmcopy -r or cbmread now no longer hangs at the end of a transfer
  * Bugfix: don't reset the bus twice if previous command was interrupted and
    this command is "cbmctrl reset".
  * Bugfix: increase reset time to 100 ms to be sure all drives are reset.
  * Linux build fix for more modern kernels

v1.1 (2011/2) -- Manual updates, no code changes

v1.0 (2011/1/10) -- Initial release of ZoomFloppy and OpenCBM code


Obtaining source code
===
This distribution is all open-source code. You can find a copy of the GPL
license in the COPYING file. You can download the source code from these
locations:

ZoomFloppy board and schematic
http://www.go4retro.com/downloads/ZoomFloppy/ZoomFloppy%20PCB%20v1.0.zip
http://www.go4retro.com/products/zoomfloppy/

xum1541 firmware and schematic
http://opencbm.git.sourceforge.net/git/gitweb.cgi?p=opencbm/opencbm;a=tree;f=xum1541

OpenCBM
http://opencbm.git.sourceforge.net/git/gitweb-index.cgi

nibtools
http://c64preservation.com/dp.php?pg=nibtools

xum1541cfg
http://www.root.org/~nate/c64/xum1541/xum1541cfg.tar.gz
